# إيفا بيوتي لاونج

- site/index.html: الموقع الكامل
- offer.html: عرض الباقات
- messages-and-offer.md: مسودات الرسائل
- research-brief.md: التحليل والمصادر
- preview-desktop.png: صورة المعاينة
- site/catalog.html + card.html + poster.html: المنتجات الإضافية

الرابط: https://az212z.github.io/waqea-new-10-20260927/eva-tabuk/
لم تُرسل رسائل للمشروع. يلزم اعتماد صاحب المشروع للمحتوى وحقوق الصور قبل التشغيل الرسمي.
